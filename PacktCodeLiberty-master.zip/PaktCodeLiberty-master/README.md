# PaktCodeLiberty
 Code associated with Hands On Xamarin.Forms
