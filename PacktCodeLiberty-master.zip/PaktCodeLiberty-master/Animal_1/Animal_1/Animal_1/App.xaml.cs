﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Animal_1.Services;
using Animal_1.Views;

namespace Animal_1
{
    public partial class App : Application
    {

        public App()
        {
            InitializeComponent();

            DependencyService.Register<MockDataStore>();
            MainPage = new AppShell();
        }



        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}
