﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Animal_1.Models
{
	public class Animal
	{
		public string Name { get; set; }
	}
}
