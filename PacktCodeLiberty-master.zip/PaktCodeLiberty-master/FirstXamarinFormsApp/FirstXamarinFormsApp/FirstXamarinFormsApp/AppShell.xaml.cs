﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace FirstXamarinFormsApp
{
   public partial class AppShell : Xamarin.Forms.Shell
   {
      public AppShell()
      {
         InitializeComponent();
      }
   }
}
